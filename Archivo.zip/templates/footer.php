</div>
    </main>
</div>
    </main>
</div>
<!-- Flatpickr JS -->
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/es.js"></script>
<script src="<?= APP_URL ?>/assets/js/admin.js?v=<?= time() ?>"></script>
</body>
</html>